// Lógica JS inicial
console.log('Dia 04 pronto!');
