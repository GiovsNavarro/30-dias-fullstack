// Lógica JS inicial
console.log('Dia 01 pronto!');
