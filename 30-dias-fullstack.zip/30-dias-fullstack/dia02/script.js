// Lógica JS inicial
console.log('Dia 02 pronto!');
