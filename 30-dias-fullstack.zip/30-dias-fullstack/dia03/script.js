// Lógica JS inicial
console.log('Dia 03 pronto!');
